import { useEffect, useState } from "react";
import axios from "axios";
import "./Appointments.css";

function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const response = await axios.get("http://localhost:8081/appointments");
        setAppointments(response.data);
      } catch (error) {
        console.error("Failed to fetch appointments", error);
        // Fallback to mock data if API fails
        setAppointments([
          {
            id: 1,
            customerName: "John Doe",
            date: "2023-12-15",
            time: "10:00 AM",
            staffAssigned: "Dr. Smith",
            status: "confirmed"
          },
          {
            id: 2,
            customerName: "Jane Smith",
            date: "2023-12-16",
            time: "2:30 PM",
            staffAssigned: "Dr. Johnson",
            status: "pending"
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchAppointments();
  }, []);

  if (loading) {
    return (
      <div className="register-container" style={{ maxWidth: '800px' }}>
        <h2>Your Appointments</h2>
        <div className="loading-state">Loading appointments...</div>
      </div>
    );
  }

  return (
    <div className="register-container" style={{ maxWidth: '800px' }}>
      <h2>Your Appointments</h2>
      
      {appointments.length === 0 ? (
        <div className="no-appointments">
          <p>No appointments scheduled yet.</p>
        </div>
      ) : (
        <div className="appointments-grid">
          {appointments.map((appointment) => (
            <div className="appointment-card" key={appointment.id}>
              <div className="appointment-row">
                <span className="appointment-label">Customer:</span>
                <span className="appointment-value">{appointment.customerName}</span>
              </div>
              <div className="appointment-row">
                <span className="appointment-label">Date:</span>
                <span className="appointment-value">{new Date(appointment.date).toLocaleDateString()}</span>
              </div>
              <div className="appointment-row">
                <span className="appointment-label">Time:</span>
                <span className="appointment-value">{appointment.time}</span>
              </div>
              <div className="appointment-row">
                <span className="appointment-label">Staff:</span>
                <span className="appointment-value">{appointment.staffAssigned}</span>
              </div>
              <div className="appointment-row">
                <span className="appointment-label">Status:</span>
                <span className={`status-badge ${appointment.status || 'pending'}`}>
                  {appointment.status === 'confirmed' ? '✓ Confirmed' : '⌛ Pending'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Appointments;